import walletModel from "../model/WalletSchema.js";
import returnModel from "../model/ReturnSchema.js";
import ProductModel from "../model/ProductSchema.js";
import mongoose from "mongoose";
const VAT_RATE = 0.05;

const walletController = {
    creditWallet: async (req, res) => {
        const session = await mongoose.startSession();
        session.startTransaction();

        try {
            const { returnid, amount } = req.body;

            // Validate inputs
            if (!returnid || !amount || amount <= 0) {
                await session.abortTransaction();
                return res.status(400).json({
                    error: "Invalid return ID or amount",
                    code: "INVALID_INPUT"
                });
            }
            // Validate returnid format
            if (!mongoose.Types.ObjectId.isValid(returnid)) {
                await session.abortTransaction();
                return res.status(400).json({
                    error: "Invalid return ID format",
                    code: "INVALID_RETURN_ID"
                });
            }

            // 1. Find return request
            const returnRequest = await returnModel.findById(returnid).session(session);;

            if (!returnRequest) {
                await session.abortTransaction();
                return res.status(404).json({
                    error: "Return request not found",
                    code: "RETURN_NOT_FOUND"
                });
            }
            if (returnRequest.returntype !== "save_to_wallet") {
                await session.abortTransaction();
                return res.status(400).json({
                    success: false,
                    error: "Return type must be 'save_to_wallet'",
                    code: "INVALID_RETURN_TYPE"
                });
            }
            // Check if return is already processed
            if (returnRequest.status === "completed" || returnRequest.status === "credited") {
                await session.abortTransaction();
                return res.status(400).json({
                    success: false,
                    error: "Return already processed",
                    code: "RETURN_ALREADY_PROCESSED"
                });
            }

            const { userid, productid, quantity, orderid } = returnRequest;

            // 2. Validate product and calculate refund
            const product = await ProductModel.findById(productid).session(session);
            if (!product) {
                await session.abortTransaction();
                return res.status(404).json({
                    success: false,
                    error: "Product not found",
                    code: "PRODUCT_NOT_FOUND"
                });
            }

            const baseAmount = Number((product.price || 0) * (quantity || 1));
            const vatAmount = Number((baseAmount * VAT_RATE).toFixed(2));
            const calculatedAmount = Number((baseAmount + vatAmount).toFixed(2));

            // Allow small rounding differences
            if (Math.abs(calculatedAmount - Number(amount)) > 0.01) {
                await session.abortTransaction();
                return res.status(400).json({
                    success: false,
                    error: "Amount doesn't match calculated refund",
                    code: "AMOUNT_MISMATCH",
                    expected: calculatedAmount,
                    received: amount
                });
            }

            // 3. Find or create wallet
            let wallet = await walletModel.findOne({ userid }).session(session);
            const isNewWallet = !wallet;

            if (isNewWallet) {
                wallet = new walletModel({
                    userid,
                    balance: 0,
                    transactions: []
                });
            }

            // 4. Check for duplicate credit
            const alreadyCredited = wallet.transactions.some(
                tx => tx.returnid && tx.returnid.toString() === returnid.toString()
            );

            if (alreadyCredited) {
                await session.abortTransaction();
                return res.status(400).json({
                    success: false,
                    alreadyWalletCredited: true,
                    error: "Wallet already credited for this return",
                    code: "DUPLICATE_CREDIT"
                });
            }

            // 5. Perform credit
            const creditAmount = Number(amount);
            const newBalance = Number((wallet.balance + creditAmount).toFixed(2));
            wallet.balance = newBalance;

            const transaction = {
                type: "credit",
                amount: creditAmount,
                note: `Refund for return ${returnid}`,
                returnid: new mongoose.Types.ObjectId(returnid),
                orderid: orderid || null,
                productid: new mongoose.Types.ObjectId(productid),
                status: "completed",
                date: new Date(),
                balanceAfter: newBalance
            };

            wallet.transactions.push(transaction);
            await wallet.save({ session });

            await returnModel.findByIdAndUpdate(
                returnid,
                {
                    status: "credited",
                    processedAt: new Date()
                },
                { session }
            );
            await session.commitTransaction();

            return res.status(200).json({
                success: true,
                newBalance: wallet.balance,
                isNewWallet,
                creditedAmount: creditAmount,
                message: "Wallet credited successfully"
            });

        } catch (error) {
            await session.abortTransaction();
            console.error("Credit wallet error:", error);
            return res.status(500).json({
                success: false,
                error: "Failed to credit wallet",
                code: "CREDIT_FAILED",
                details: process.env.NODE_ENV === 'development' ? error.message : undefined
            });
        } finally {
            session.endSession();
        }
    },

    processWalletPayment: async (req, res) => {
        const session = await mongoose.startSession();
        session.startTransaction();
        console.log("Processing wallet payment request:", req.body);
        try {
            const { userid, orderTotalAmt, orderid, paymentMethod } = req.body;

            // Validate inputs
            if (!userid || !orderTotalAmt || orderTotalAmt <= 0 || !orderid) {
                await session.abortTransaction();
                return res.status(400).json({
                    error: "Invalid payment request",
                    code: "INVALID_REQUEST"
                });
            }
            // Validate userid format
            if (!mongoose.Types.ObjectId.isValid(userid)) {
                await session.abortTransaction();
                return res.status(400).json({
                    success: false,
                    error: "Invalid user ID format",
                    code: "INVALID_USER_ID"
                });
            }
            const totalAmount = Number(orderTotalAmt);


            if (paymentMethod === 'wallet' || paymentMethod === 'wallet_partial') {
                const wallet = await walletModel.findOne({ userid }).session(session);
                if (!wallet) {
                    await session.abortTransaction();
                    return res.status(404).json({
                        success: false,
                        error: "Wallet not found",
                        code: "WALLET_NOT_FOUND",
                        paymentRequired: totalAmount
                    });
                }
                // Check for duplicate payment
                const existingPayment = wallet.transactions.find(
                    tx => tx.type === "debit" &&
                        tx.orderid?.toString() === orderid.toString() &&
                        tx.status === "completed"
                );

                if (existingPayment) {
                    await session.abortTransaction();
                    return res.status(400).json({
                        success: false,
                        error: "Payment already processed for this order",
                        code: "DUPLICATE_PAYMENT"
                    });
                }

                const amountPaid = Math.min(wallet.balance, totalAmount);
                const remainingAmount = Number((totalAmount - amountPaid).toFixed(2));

                console.log("Payment details:", {
                    walletBalance: wallet.balance,
                    totalAmount,
                    amountPaid,
                    remainingAmount
                });

                // Only proceed if wallet can cover at least part of payment
                if (amountPaid <= 0) {
                    await session.abortTransaction();
                    return res.status(400).json({
                        success: false,
                        error: "Insufficient wallet balance",
                        code: "INSUFFICIENT_BALANCE",
                        currentBalance: wallet.balance,
                        requiredAmount: totalAmount,
                        remainingAmount: totalAmount
                    });
                }

                // Update wallet balance
                const newBalance = Number((wallet.balance - amountPaid).toFixed(2));
                wallet.balance = newBalance;

                const transaction = {
                    type: "debit",
                    amount: Number(amountPaid.toFixed(2)),
                    note: `Payment for order ${orderid}`,
                    orderid: orderid,
                    status: "completed",
                    date: new Date(),
                    balanceAfter: newBalance
                };

                wallet.transactions.push(transaction);
                await wallet.save({ session });

                await session.commitTransaction();

                return res.status(200).json({
                    success: true,
                    paymentMethod: remainingAmount > 0 ? 'wallet_partial' : 'wallet',
                    amountPaidFromWallet: Number(amountPaid.toFixed(2)),
                    remainingAmount,
                    newBalance: wallet.balance,
                    message: remainingAmount > 0 ?
                        `Partial payment completed. Remaining: AED ${remainingAmount}` :
                        "Payment completed successfully"
                });
            }

            // Handle other payment methods if needed
            await session.commitTransaction();
            return res.status(200).json({
                success: true,
                paymentMethod,
                amountPaidFromWallet: 0,
                remainingAmount: totalAmount,
                message: "Payment method processed"

            });

        } catch (error) {
            await session.abortTransaction();
            console.error("Payment processing error:", error);
            return res.status(500).json({
                success: false,
                error: "Payment failed",
                code: "PAYMENT_FAILED",
                message: process.env.NODE_ENV === 'development' ? error.message : undefined

            });
        } finally {
            session.endSession();
        }
    },

    getWallet: async (req, res) => {
        try {
            const userid = req.userid;
            // Validate user ID
            if (!userid || !mongoose.Types.ObjectId.isValid(userid)) {
                return res.status(400).json({
                    success: false,
                    error: "Invalid user ID",
                    code: "INVALID_USER_ID"
                });
            }

            // Get wallet (lean for better performance)
            const wallet = await walletModel.findOne({ userid })
                .populate({
                    path: 'transactions.productid',
                    select: 'name image productid'
                })
                .populate({
                    path: 'transactions.orderid',
                    select: 'orderid status'
                })
                .lean();

            if (!wallet) {
                return res.status(200).json({
                    success: true,
                    wallet: {
                        balance: 0,
                        transactions: [],
                        currency: 'AED'
                    }
                });
            }

            // Format transactions (newest first) with proper error handling
            const formattedTransactions = (wallet.transactions || [])
                .sort((a, b) => new Date(b.date) - new Date(a.date))
                .map(tx => ({
                    _id: tx._id,
                    type: tx.type,
                    amount: Number(tx.amount) || 0,
                    note: tx.note || '',
                    status: tx.status || 'completed',
                    date: tx.date ? new Date(tx.date).toISOString() : new Date().toISOString(),
                    balanceAfter: tx.balanceAfter || null,
                    orderid: tx.orderid || null,
                    productid: tx.productid || null,
                    returnid: tx.returnid || null
                }));

            return res.status(200).json({
                success: true,
                wallet: {
                    balance: Number(wallet.balance) || 0,
                    transactions: formattedTransactions,
                    currency: 'AED',
                    lastUpdated: new Date().toISOString()
                }
            });

        } catch (error) {
            console.error("Get wallet error:", error);
            return res.status(500).json({
                success: false,
                error: "Failed to fetch wallet",
                code: "FETCH_FAILED",
                message: process.env.NODE_ENV === 'development' ? error.message : "Internal server error"
            });
        }
    },
    debitWallet: async (req, res) => {
        const session = await mongoose.startSession();
        session.startTransaction();

        try {
            const { userid, amount, orderid, note } = req.body;

            // Validate inputs
            if (!userid || !amount || amount <= 0) {
                await session.abortTransaction();
                return res.status(400).json({
                    success: false,
                    error: "Missing required fields",
                    code: "MISSING_FIELDS"
                });
            }
            // Validate userid format
            if (!mongoose.Types.ObjectId.isValid(userid)) {
                await session.abortTransaction();
                return res.status(400).json({
                    success: false,
                    error: "Invalid user ID format",
                    code: "INVALID_USER_ID"
                });
            }

            const debitAmount = Number(amount);

            // 1. Get and lock wallet
            const wallet = await walletModel.findOne({ userid }).session(session);
            if (!wallet) {
                await session.abortTransaction();
                return res.status(404).json({
                    error: "Wallet not found",
                    code: "WALLET_NOT_FOUND"
                });
            }

            // 2. Validate sufficient balance
            if (wallet.balance < debitAmount) {
                await session.abortTransaction();
                return res.status(400).json({
                    success: false,
                    error: "Insufficient wallet balance",
                    code: "INSUFFICIENT_BALANCE",
                    currentBalance: wallet.balance,
                    requiredAmt: debitAmount
                });
            }

            if (orderid) {
                const existingDebit = wallet.transactions.find(
                    tx => tx.type === "debit" &&
                        tx.orderid && tx.orderid.toString() === orderid.toString() &&
                        tx.status === "completed"
                );

                if (existingDebit) {
                    await session.abortTransaction();
                    return res.status(400).json({
                        error: "Payment already processed for this order",
                        code: "DUPLICATE_PAYMENT"
                    });
                }
            }

            // 3. Perform debit
            const newBalance = Number((wallet.balance - debitAmount).toFixed(2));
            wallet.balance = newBalance;


            const transaction = {
                type: "debit",
                amount: debitAmount,
                note: note || (orderid ? `Payment for order ${orderid}` : 'Wallet debit'),
                orderid: orderid || null,
                status: "completed",
                date: new Date(),
                balanceAfter: newBalance
            };


            wallet.transactions.push(transaction);
            await wallet.save({ session });

            await session.commitTransaction();

            return res.status(200).json({
                success: true,
                newBalance: wallet.balance,

                debitedAmount: debitAmount,
                message: "Wallet debited successfully"
            });

        } catch (error) {
            await session.abortTransaction();
            console.error("Debit wallet error:", error);
            return res.status(500).json({
                success: false,
                error: "Failed to debit wallet",
                code: "DEBIT_FAILED",
                message: process.env.NODE_ENV === 'development' ? error.message : "Internal server error"
            });
        } finally {
            session.endSession();
        }
    }
}
export default walletController;