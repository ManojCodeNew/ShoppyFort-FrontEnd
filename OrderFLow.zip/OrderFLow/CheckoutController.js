import Stripe from 'stripe';
import dotenv from 'dotenv';
import cartModel from '../model/CartSchema.js';
const envFile = `.env.${process.env.NODE_ENV || 'development'}`;
dotenv.config({ path: envFile });
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

const checkoutController = {
    createPaymentIntent: async (req, res) => {
        const { amount } = req.body;
        // console.log(amount);


        try {
            if (!amount || isNaN(amount)) {
                return res.status(400).json({ error: "Invalid or missing amount" });
            }

            const paymentIntent = await stripe.paymentIntents.create({
                amount: amount,
                currency: "aed",
            });
            console.log("amount", amount, "Payment Intent", paymentIntent);

            res.status(200).json({ clientSecret: paymentIntent.client_secret });
        } catch (error) {
            console.error("Error creating payment intent:", error);
            res.status(500).json({ error: error.message });
        }
    },

}

export default checkoutController;