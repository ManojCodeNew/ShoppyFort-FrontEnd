import express from 'express';
import checkoutController from '../controller/CheckoutController.js';
const router = express.Router();

router.post('/create-payment-intent', checkoutController.createPaymentIntent);
export default router;