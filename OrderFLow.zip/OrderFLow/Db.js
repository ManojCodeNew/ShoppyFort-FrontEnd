// This code sets up an Express.js server with MongoDB, AWS S3, and various routes for handling products, users, orders, and more. It includes CORS configuration, error handling, file uploads to S3, and security measures using Helmet.
// Backend/Connections/server.js
import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import ProductRoute from "./routes/ProductRoute.js";
import AddressRoute from "./routes/AddressRoute.js";
import userRoute from "./routes/UserRoute.js";
import wishlistRoute from './routes/WishlistRoute.js';
import cartRoute from './routes/CartRoute.js';
import orderRoute from './routes/OrderRoute.js';
import AdminProductsRoute from './routes/AdminProductsRoute.js';
import AdminOrdersRoute from './routes/AdminOrdersRoute.js';
import AdminDashboardRoute from './routes/AdminDashboardRoute.js';
import AdminReturnsRoute from './routes/AdminReturnsRoute.js';
import Checkout from './routes/Checkout.js';
import walletRoute from './routes/WalletRoute.js';
import AdminOffersRoute from './routes/AdminOffersRoute.js';
import AdminOffersController from './controller/AdminOffersController.js';
import OffersRoute from './routes/OffersRoute.js';
import adminRouter from './routes/AdminRoutes.js';
import multer from 'multer';
import { S3Client, PutObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import Stripe from 'stripe';
//compression : Almost always. It’s especially helpful when sending large data like HTML, CSS, JS, or JSON responses.
import compression from 'compression';
// helmet : These headers protect your app from common web vulnerabilities like:
// Cross-Site Scripting (XSS)
// Clickjacking
// MIME-sniffing
// DNS prefetching
import helmet from 'helmet';
import dotenv from 'dotenv';
import { authenticateAdmin } from './middlewares/adminMiddleware.js';

// Load environment variables from .env file
dotenv.config({
    path: process.env.NODE_ENV === 'production' ? '.env.production' : '.env.development'
});

console.log("NODE_ENV:", process.env.NODE_ENV);
console.log("Stripe Key Loaded:", process.env.STRIPE_SECRET_KEY ? "✅ Yes" : "❌ No");

// Initialize Stripe with your secret key
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// Express setup
const app = express();

// Parse incoming requests with JSON payloads
const allowedOrigins = [
    "https://shoppyfort.com",
    "https://www.shoppyfort.com",
    "http://localhost:3000",
    "http://localhost:5173",
    "http://localhost:5174",
    "https://1.app.api.shoppyfort.com"
];

// Enhanced CORS configuration with proper credentials handling
app.use(cors({
    origin: function (origin, callback) {

        // Allow requests with no origin (mobile apps, Postman, etc.)
        if (!origin) {
            return callback(null, true);
        }

        if (allowedOrigins.includes(origin)) {
            return callback(null, true);
        }

        callback(new Error(`CORS Error: Origin ${origin} not allowed`));
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
    allowedHeaders: [
        'Origin',
        'X-Requested-With',
        'Content-Type',
        'Accept',
        'Authorization',
        'Cache-Control',
        'Pragma'
    ],
    exposedHeaders: ['Set-Cookie'],
    optionsSuccessStatus: 200
}));
app.use(express.json({
    limit: '500mb',
    parameterLimit: 100000
}));

// encrypt request data(formdata)
app.use(express.urlencoded({
    extended: true,
    limit: '500mb',
    parameterLimit: 500000
}));
// Add request timeout handling
app.use((req, res, next) => {
    // Set timeout for file uploads (5 minutes)
    req.setTimeout(300000);
    res.setTimeout(300000);
    next();
});

// Add preflight handling for all routes
app.options('*', cors());

// Additional CORS headers middleware for extra safety
app.use((req, res, next) => {
    const origin = req.headers.origin;

    // Only set specific origin if it's in our allowed list
    if (origin && allowedOrigins.includes(origin)) {
        res.header('Access-Control-Allow-Origin', origin);
    }

    res.header('Access-Control-Allow-Credentials', 'true');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS,PATCH');
    res.header('Access-Control-Allow-Headers',
        'Origin, X-Requested-With, Content-Type, Accept, Authorization, Cache-Control, Pragma');

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.sendStatus(200);
        return;
    }

    next();
});

app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            scriptSrc: ["'self'"],
            imgSrc: ["'self'", "data:", `https://${process.env.AWS_BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com`]
        }
    }
})); // Use Helmet to set security-related HTTP headers
app.use(compression()); // Enable compression for responses

const mongoOptions = {
    maxPoolSize: parseInt(process.env.MONGODB_MAX_POOLSIZE) || 10,
    minPoolSize: parseInt(process.env.MONGODB_MIN_POOLSIZE) || 2,
    serverSelectionTimeoutMS: 30000,
    socketTimeoutMS: 30000
};

// MongoDB connection
const connectDB = async () => {
    try {
        const conn = await mongoose.connect(process.env.MONGODB_URI, mongoOptions);
        return conn;
    } catch (error) {
        console.error('MongoDB connection error:', error);
        process.exit(1);
    }
};


// AWS S3 Configuration
// AWS S3 Configuration using v3 SDK
const s3 = new S3Client({
    region: process.env.AWS_REGION,
    credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    },
});

// Multer Setup (Memory Storage)
const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
        fileSize: 500 * 1024 * 1024,//Max 500MB per file
        files: 100,
        fieldSize: 500 * 1024 * 1024, // 500MB for non-file fields
        fieldNameSize: 1000, // Max field name size
        headerPairs: 2000 // Max number of header key-value pairs
    },
    fileFilter: (req, file, cb) => {
        // Check file type
        if (!file.mimetype.startsWith('image/')) {
            return cb(new Error('Only image files are allowed'), false);
        }
        cb(null, true);
    }
});

app.use((error, req, res, next) => {
    if (error instanceof multer.MulterError) {
        if (error.code === 'LIMIT_FILE_SIZE') {
            return res.status(413).json({
                error: 'File too large',
                message: 'File size exceeds 100MB limit',
                code: 'FILE_TOO_LARGE'
            });
        }
        if (error.code === 'LIMIT_FILE_COUNT') {
            return res.status(413).json({
                error: 'Too many files',
                message: 'Maximum 100 files allowed',
                code: 'TOO_MANY_FILES'
            });
        }
        if (error.code === 'LIMIT_UNEXPECTED_FILE') {
            return res.status(400).json({
                error: 'Unexpected field',
                message: 'Unexpected file field',
                code: 'UNEXPECTED_FIELD'
            });
        }
    }
    next(error);
});

// Helper function to generate an S3 key
const generateS3Key = (folder, subfolder1, subfolder2, originalname) => {
    const timestamp = Date.now();
    // Sanitize folder names to be URL-friendly
    const sanitizedSubfolder1 = subfolder1.replace(/[^a-zA-Z0-9-]/g, '_').toLowerCase();
    const sanitizedSubfolder2 = subfolder2.replace(/[^a-zA-Z0-9-]/g, '_').toLowerCase();
    const sanitizedFilename = originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
    return `${folder}/${sanitizedSubfolder1}/${sanitizedSubfolder2}/${timestamp}_${sanitizedFilename}`;
};

// Function to upload a single file to S3
const uploadToS3 = async (file, s3Key, contentType = file.mimetype) => {
    try {

        const params = {
            Bucket: process.env.AWS_BUCKET_NAME,
            Key: s3Key,
            Body: file.buffer,
            ContentType: contentType,
            ServerSideEncryption: 'AES256',//Add encryption
            CacheControl: 'max-age=31536000',
        };
        const command = new PutObjectCommand(params);
        await s3.send(command);
        console.log(`Successfully uploaded: ${s3Key}`);

        // Generate path
        return s3Key;
    } catch (error) {
        console.error("Error uploading file to S3:", error);
        throw new Error(`S3 upload failed: ${error.message}`);
    }
};

app.post("/upload-product-images", authenticateAdmin, upload.array("images", 100), async (req, res) => {
    console.log("Image uploading request received");
    console.log("Admin user:", req.admin ? 'Authenticated' : 'Not authenticated');
    console.log("Files received:", req.files ? req.files.length : 0);
    console.log("Request origin:", req.headers.origin);
    try {
        if (!req.admin) {
            console.log("Authentication failed: Admin not found");
            return res.status(401).json({
                error: 'Admin authentication required',
                code: 'ADMIN_AUTH_REQUIRED'
            });
        }

        const { productName, colorImages } = req.body;
        console.log("Image Upload Error:", productName, colorImages);
        if (!req.files || req.files.length === 0) {
            return res.status(400).json({ error: "No files uploaded", code: "NO_FILES_UPLOADED" });
        }
        if (!productName || !colorImages) {
            return res.status(400).json({ error: "Missing productName or colorImages", code: "MISSING_FIELDS" });
        }
        // Log file sizes for debugging
        req.files.forEach((file, index) => {
            console.log(`File ${index + 1}: ${file.originalname} - ${(file.size / 1024 / 1024).toFixed(2)}MB`);
        });

        let colorMapping;
        try {
            colorMapping = JSON.parse(colorImages);
        } catch (parseError) {
            return res.status(400).json({
                error: "Invalid JSON in colorImages field",
                code: "INVALID_JSON",
                details: parseError.message
            });
        }
        const uploadPromises = [];

        // Loop through each color in the mapping
        for (const [color, imageNames] of Object.entries(colorMapping)) {
            const filesForColor = req.files.filter((file) => imageNames.includes(file.originalname));

            if (filesForColor.length > 0) {
                const colorUploadPromise = Promise.all(
                    filesForColor.map(async (file) => {
                        try {
                            const key = generateS3Key('product_images', productName, color, file.originalname);
                            const result = await uploadToS3(file, key);
                            console.log(`Successfully uploaded: ${file.originalname} to ${key}`);
                            return result;
                        } catch (uploadError) {
                            console.error(`Failed to upload ${file.originalname}:`, uploadError);
                            throw new Error(`Failed to upload ${file.originalname}: ${uploadError.message}`);
                        }
                    })
                ).then(keys => ({ color, keys }));

                uploadPromises.push(colorUploadPromise);
            }
        }


        if (uploadPromises.length === 0) {
            return res.status(400).json({
                error: "No matching files found for the specified colors",
                code: "NO_MATCHING_FILES"
            });
        }

        const uploadedFiles = await Promise.all(uploadPromises);
        // uploadedFiles.push(...results);
        // Check if uploads were successful
        if (uploadedFiles.length === 0) {
            return res.status(500).json({ error: "Failed to upload any files" });
        }

        console.log("Upload completed successfully");
        res.status(200).json({
            success: true,
            message: "Files uploaded successfully!",
            paths: uploadedFiles,
            totalFiles: req.files.length
        });


    } catch (error) {
        console.error("Failed to upload files:", error);
        // Handle specific error types
        if (error.code === 'LIMIT_FILE_SIZE') {
            return res.status(413).json({
                error: "File too large",
                message: "One or more files exceed the 100MB limit",
                code: "FILE_TOO_LARGE"
            });
        }
        if (error.code === 'LIMIT_FILE_COUNT') {
            return res.status(413).json({
                error: "Too many files",
                message: "Maximum 100 files allowed per request",
                code: "TOO_MANY_FILES"
            });
        }

        res.status(500).json({
            error: "Failed to upload files",
            message: error.message,
            code: "UPLOAD_FAILED"
        });
    }
});


app.post("/admin/upload/offer", authenticateAdmin, upload.single("offerImage"), async (req, res) => {
    try {
        console.log("Offers image", req.body);
        const { title, description, discountText, productIds } = req.body;
        const file = req.file;
        console.log("Add Offer Dta", req.body);

        if (!file) {
            return res.status(400).json({
                error: "No image file provided",
                code: "NO_FILE"
            });
        }

        if (!title || !description) {
            return res.status(400).json({
                error: "Missing required fields: title and description",
                code: "MISSING_FIELDS"
            });
        }

        const s3Key = await uploadToS3(file, generateS3Key('offer_images', title, 'main', file.originalname)); // Modified S3 key
        const imageUrl = `https://${process.env.AWS_BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${s3Key}`;

        // Call the controller function to save the offer data
        req.body.imageUrl = imageUrl;
        req.body.s3Key = s3Key;

        AdminOffersController.addOffer(req, res); // Pass the modified req and res

    } catch (error) {
        console.error("Failed to upload offer image:", error);
        res.status(500).json({
            error: "Failed to upload offer image",
            message: error.message,
            code: "OFFER_UPLOAD_FAILED"
        });
    }
});

app.delete("/delete-image", async (req, res) => {
    try {
        const { imagePath } = req.body;
        console.log("Received imagePath for deletion:", req.body);

        if (!imagePath) {
            return res.status(400).json({ message: "Missing image path." });
        }

        const params = {
            Bucket: process.env.AWS_BUCKET_NAME,
            Key: imagePath, // The exact path inside the bucket
        };

        console.log(`Deleting image from S3: ${imagePath}`);

        const command = new DeleteObjectCommand(params);
        await s3.send(command);

        res.status(200).json({ success: "Image deleted successfully.", path: imagePath });
    } catch (error) {
        console.error("Error deleting image from S3:", error);
        // Handle specific S3 errors
        if (error.name === 'NoSuchKey') {
            return res.status(404).json({
                error: "Image not found",
                code: "IMAGE_NOT_FOUND"
            });
        }

        res.status(500).json({
            error: "Failed to delete image",
            message: error.message,
            code: "DELETE_FAILED"
        });
    }
});
// Routes setup
app.use('/api/products', ProductRoute);
app.use('/checkout', AddressRoute);
app.use('/auth', userRoute);
app.use('/wishlist', wishlistRoute);
app.use('/cart', cartRoute);
app.use('/order', orderRoute);
app.use('/api/offers', OffersRoute);
app.use('/payments', Checkout);

app.use('/admin', adminRouter);
app.use('/admin/products', AdminProductsRoute);
app.use('/admin/dashboard', AdminDashboardRoute);
app.use('/admin/orders', AdminOrdersRoute);
app.use('/admin/returns', AdminReturnsRoute);
app.use('/admin/wallet', walletRoute);
app.use('/auth/wallet', walletRoute);
app.use('/admin/offers', AdminOffersRoute);



// Global error handler should be LAST
app.use((error, req, res, next) => {
    console.error('Error:', error);

    if (error.message && error.message.includes('CORS')) {
        return res.status(403).json({
            error: 'CORS policy violation',
            message: 'This origin is not allowed to access this resource'
        });
    }

    res.status(error.status || 500).json({
        error: 'Internal server error',
        message: process.env.NODE_ENV === 'development' ? error.message : 'Something went wrong'
    });
});
// Catch-all route for 404 errors
app.use('*', (req, res) => {
    res.status(404).json({
        error: 'Route not found',
        path: req.originalUrl
    });
});

// Start server after DB connection
const startServer = async () => {
    try {
        await connectDB();

        const PORT = process.env.PORT || 3000;
        app.listen(PORT, () => {
            console.log(`Server running on port ${PORT}`);
            console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
        });

    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
};

startServer();


