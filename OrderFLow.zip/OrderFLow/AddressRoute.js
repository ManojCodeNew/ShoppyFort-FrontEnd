import express from 'express';
import AddressController from '../controller/AddressController.js';
import verifyToken from '../middlewares/authMiddleware.js';
const router = express.Router();
router.post('/addAddress', verifyToken, AddressController.addAddress);
router.get('/Address', verifyToken, AddressController.getAllAddress);
router.post('/Address/remove', verifyToken, AddressController.removeAddress);

export default router;