import mongoose from "mongoose";
const ReturnSchema = new mongoose.Schema({
    orderid: {
        type: String,
        required: true
    },
    userid: {
        type: String,
        required: true
    },
    productid: {
        type: String,
        required: true
    },
    quantity: {
        type: Number,
        required: true,
        min: 1,
        default: 1
    },
    reason: {
        type: String,
        required: true
    },
    returntype: {
        type: String,
        enum: ['replacement', 'save_to_wallet'],
        required: true
    },
    status: {
        type: String,
        enum: [
            'return_requested',
            'approved_by_shop_owner',
            'pickup_scheduled',
            'picked_up',
            'replacement_shipped',
            'delivered',
            'rejected',
            'processed'
        ],
        default: 'return_requested'
    }
}, {
    timestamps: true
});
const returnModel = mongoose.model('Return', ReturnSchema);
export default returnModel;