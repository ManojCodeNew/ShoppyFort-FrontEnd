import cartModel from "../model/CartSchema.js";
const cartController = {

    // In your backend controller
    addCartProduct: async (req, res) => {
        try {
            const { productid, quantity, selections } = req.body;
            const existingProduct = await cartModel.findOne({ userid: req.userid, productid });

            if (existingProduct) {
                // Update existing cart product instead of returning error
                existingProduct.quantity = quantity;
                existingProduct.selections = selections;
                await existingProduct.save();
                return res.json({ success: "Cart updated successfully" });
            }

            // Create new cart product if it doesn't exist
            const newCartProduct = new cartModel({ userid: req.userid, productid, quantity, selections });
            await newCartProduct.save();
            console.log("Product added to cart successfully", newCartProduct);
            
            res.json({ success: "Success to add" });
        } catch (error) {
            res.json({ error: error})
        }
    },

    getAllCart: async (req, res) => {
        try {
            const carts = await cartModel.find({ userid: req.userid });

            res.json({ success: "carts added success", carts });
        } catch (error) {
            res.json({ er: "error" });
        }
    },
    clearCart: async (req, res) => {
        try {
            if (!req.userid) {
                return res.status(401).json({ error: "Unauthorized: User ID not found" });
            }
            await cartModel.deleteMany({ userid: req.userid });
            console.log("Cart cleared successfully for user:", req.userid);
            res.status(200).json({
                success: true,
                message: 'Cart cleared successfully'
            });
        } catch (error) {

        }
    },

    removeCart: async (req, res) => {
        try {
            const { productid } = req.body;
            const findUser = await cartModel.findOne({ userid: req.userid, productid });

            if (!findUser) {
                return res.json({ msg: "Item not found in Cart" });
            }
            const result = await cartModel.deleteOne({ userid: req.userid, productid });
            if (result.deletedCount >= 1) {
                return res.json({ success: "Item removed from Cart" });
            } else {
                return res.json({ msg: "Item not removed from Cart" });
            }
        } catch (error) {
            return res.status(500).json({ error: "Internal server error" });
        }
    },


    updateQuantity: async (req, res) => {
        try {
            const { productid, quantity } = req.body;
            const result = await cartModel.updateOne({ userid: req.userid, productid }, { $set: { quantity } });
            if (result.matchedCount >= 1) {
                res.json({ success: "Cart updated successfullly" });
            } else {
                res.json({ msg: "No matching item found in Cart" });
            }
        } catch (error) {
            res.json({ er: "An error occurred while updating the cart" });
        }
    }

}
export default cartController;