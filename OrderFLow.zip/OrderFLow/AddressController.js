import AddressModel from "../model/AddressSchema.js";
const AddressController = {
    addAddress: async (req, res) => {
        try {

            const { username, mobileno, buildingNumber, streetName, area, city, emirate, country, pobox, savedaddressas, defaultaddress } = req.body;

            // Validation checks
            if (!req.userid) {
                console.log('Authentication failed: No userid in request');
                return res.status(401).json({
                    success: false,
                    error: "User not authenticated"
                });
            }
            const missingFields = [];
            if (!username || username.trim() === '') missingFields.push('username');
            if (!mobileno || mobileno.trim() === '') missingFields.push('mobileno');
            if (!buildingNumber || buildingNumber.trim() === '') missingFields.push('buildingNumber');
            if (!streetName || streetName.trim() === '') missingFields.push('streetName');
            if (!area || area.trim() === '') missingFields.push('area');
            if (!savedaddressas || savedaddressas.trim() === '') missingFields.push('savedaddressas');

            if (missingFields.length > 0) {
                console.log('Validation failed. Missing fields:', missingFields);
                return res.status(400).json({
                    success: false,
                    error: `Missing required fields: ${missingFields.join(', ')}`
                });
            }

            const addressData = {
                userid: req.userid,
                username: username.trim(),
                mobileno: mobileno.trim(),
                buildingNumber: buildingNumber.trim(),
                streetName: streetName.trim(),
                area: area.trim(),
                city: city && city.trim() ? city.trim() : 'Dubai',
                emirate: emirate && emirate.trim() ? emirate.trim() : 'Dubai',
                country: country && country.trim() ? country.trim() : 'United Arab Emirates',
                pobox: pobox ? pobox.trim() : '',
                savedaddressas: savedaddressas.trim(),
                defaultaddress: Boolean(defaultaddress)
            };

            // If this is set as default, remove default from other addresses
            if (addressData.defaultaddress) {
                console.log('Setting as default address, removing default from others');
                await AddressModel.updateMany(
                    { userid: req.userid },
                    { defaultaddress: false }
                );
            }

            const newAddress = new AddressModel(addressData);
            const savedAddress = await newAddress.save();
            res.status(201).json({
                success: true,
                message: "Address added successfully",
                addressId: savedAddress._id
            });

        } catch (error) {
            // Handle specific MongoDB errors
            if (error.name === 'ValidationError') {
                const validationErrors = Object.values(error.errors).map(err => err.message);
                return res.status(400).json({
                    success: false,
                    error: `Validation error: ${validationErrors.join(', ')}`
                });
            }

            if (error.code === 11000) {
                return res.status(400).json({
                    success: false,
                    error: "Duplicate address entry"
                });
            }

            res.status(500).json({
                success: false,
                error: "Internal server error while adding address"
            });
        }
    },
    getAllAddress: async (req, res) => {
        if (!req.userid) {
            return res.status(401).json({
                success: false,
                error: "User not authenticated"
            });
        }
        try {
            const address = await AddressModel.find({ userid: req.userid }).sort({ defaultaddress: -1, createdAt: -1 });
            res.json({
                success: true,
                message: "Addresses fetched successfully",
                address: address
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                error: "Error fetching addresses"
            });

        }
    },
    removeAddress: async (req, res) => {
        try {
            const { addressid } = req.body;
            if (!addressid) {
                return res.status(400).json({
                    success: false,
                    error: "Address ID is required"
                });
            }


            if (!req.userid) {
                return res.status(401).json({
                    success: false,
                    error: "User not authenticated"
                });
            }

            const result = await AddressModel.deleteOne({
                _id: addressid,
                userid: req.userid
            });
            if (result.deletedCount >= 1) {
                res.json({
                    success: true,
                    message: "Address removed successfully"
                });
            } else {
                res.status(404).json({
                    success: false,
                    error: "Address not found or unauthorized"
                });
            }
        } catch (error) {
            res.status(500).json({
                success: false,
                error: "Error removing address"
            });
        }
    },
}
export default AddressController;