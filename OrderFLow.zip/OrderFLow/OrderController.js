import orderModel from "../model/OrderSchema.js";
import returnModel from "../model/ReturnSchema.js";
import ProductModel from "../model/ProductSchema.js";
const orderController = {
    addOrder: async (req, res) => {
        try {
            const { orderid, userid, shippingaddress, items, totalprice, paymentMethod, isPaid, amountPaidFromWallet, paymentDetails } = req.body;

            if (!orderid || !userid || !shippingaddress || !items || !totalprice) {
                return res.status(400).json({ error: "Missing required fields" });
            }
            // Check if the orderid already exists to avoid duplicates
            const existingOrder = await orderModel.findOne({ orderid });
            if (existingOrder) {
                return res.status(400).json({ error: `Order ID ${orderid} already exists` });
            }

            const newOrder = new orderModel({ orderid, userid, shippingaddress, items, totalprice, paymentMethod, amountPaidFromWallet, paymentDetails, isPaid });
            await newOrder.save();

            // Update stock for each product
            for (let item of items) {
                const product = await ProductModel.findById(item._id);
                if (!product) {
                    return res.status(404).json({ success: false, error: `Product with ID ${item.productid} not found` });
                }


                if (product.stock < item.quantity) {
                    return res.status(400).json({ success: false, error: `Insufficient stock for ${product.name}` });
                }

                product.stock -= item.quantity;
                await product.save();
            }

            res.json({ success: "Order Saved Successfully", order: newOrder });

        } catch (error) {
            console.error('Error placing order:', error);
            res.status(500).json({ success: false, error: 'Server error while placing order' });
        }

    },
    getALLOrders: async (req, res) => {
        try {
            if (!req.userid) {
                return res.status(401).json({ error: "Unauthorized: User ID not found" });
            }

            const orders = await orderModel.find({ userid: req.userid });

            if (!orders.length) {
                return res.json({ message: "No orders found for this user" });
            }

            res.json({ success: "Orders loaded successfully", orders });
        } catch (error) {
            res.status(500).json({ error: "Internal Server Error" });
        }
    },
    submitReturnRequest: async (req, res) => {
        try {
            if (!req.userid) {
                return res.status(401).json({ error: "Unauthorized: User ID not found" });
            }
            const { userid, orderid, productid, reason, returntype, quantity, status } = req.body;
            // console.log(productid, "- userid:", userid, "- orderid", orderid);

            if (!orderid || !reason) {
                return res.status(400).json({ error: "Missing required fields: orderId and reason" })
            }

            const orderIsDelivered = await orderModel.findOne({
                _id: orderid,
                userid: userid,
                status: "Delivered"
            });
            if (!orderIsDelivered) {
                return res.status(400).json({ msg: "Order not found or not eligible for return" })
            }

            const returnExist = await returnModel.findOne({
                orderid: orderid,
                productid: productid,
                userid: userid
            })

            if (returnExist) {
                return res.status(400).json({ msg: "Return request already exists for this order" })
            }

            const newReturn = await returnModel({ orderid, userid, productid, reason, returntype, quantity, status });
            await newReturn.save();

            res.status(200).json({ success: "Return Request submitted" })
        } catch (error) {
            res.status(400).json({ error: error });
        }
    },
    cancelOrder: async (req, res) => {
        try {
            if (!req.userid) {
                return res.status(401).json({ error: "Unauthorized: User ID not found" });
            }

            const { orderid } = req.body; // Remove 'status' from destructuring since we hardcode it

            if (!orderid) {
                return res.status(400).json({ error: "Order ID is required" });
            }

            // First check if order exists and is cancellable
            const order = await orderModel.findOne({
                _id: orderid,
                userid: req.userid
            });

            if (!order) {
                return res.status(404).json({ error: "Order not found or doesn't belong to user" });
            }

            // Validate order can be cancelled
            if (order.status.toLowerCase() === 'cancelled') {
                return res.status(400).json({ error: "Order is already cancelled" });
            }

            if (order.status.toLowerCase() === 'delivered') {
                return res.status(400).json({ error: "Delivered orders cannot be cancelled" });
            }

            // Update order status
            const updatedOrder = await orderModel.findOneAndUpdate(
                {
                    _id: orderid,
                    userid: req.userid,
                    status: { $ne: "Cancelled" } // Additional safety check
                },
                {
                    $set: {
                        status: "Cancelled", // Hardcoded to avoid arbitrary status changes
                        cancelledAt: new Date()
                    }
                },
                {
                    new: true,
                }
            );

            if (!updatedOrder) {
                return res.status(400).json({ error: "Order could not be cancelled" });
            }

            res.json({
                success: true,
                message: "Order cancelled successfully",
                order: updatedOrder // Return the updated order
            });

        } catch (error) {
            // console.error("Error cancelling order:", error);
            res.status(500).json({
                error: "Internal server error",
                details: error.message
            });
        }
    },
    getReturns: async (req, res) => {
        try {
            if (!req.userid) {
                return res.status(401).json({ error: "Unauthorized: User ID not found" });
            }
            const returns = await returnModel.find({ userid: req.userid });
            res.json({ success: true, data: returns });

        } catch (error) {
            res.status(500).json({ error: "Server error" });
        }
    }

}
export default orderController;
