import mongoose from 'mongoose';

const addressSchema = new mongoose.Schema({
    userid: {
        type: String,
        required: true
    },
    username: {
        type: String,
        required: true,
        trim: true
    },
    mobileno: {
        type: String,
        required: true
    },
    buildingNumber: {
        type: String,
        required: true,
        trim: true
    },
    streetName: {
        type: String,
        required: true,
        trim: true
    },
    area: {
        type: String,
        required: true,
        trim: true
    },
    city: {
        type: String,
        required: true,
        trim: true,
        default: 'Dubai'
    },
    emirate: {
        type: String,
        required: true,
        default: 'Dubai'
    },
    country: {
        type: String,
        required: true,
        default: 'United Arab Emirates'
    },
    pobox: {
        type: String,
        trim: true
    },
    savedaddressas: {
        type: String,
        required: true
    },
    defaultaddress: {
        type: String,
    },
},
    {
        timestamps: true
    });
const AddressModel = mongoose.model('address', addressSchema);

export default AddressModel;