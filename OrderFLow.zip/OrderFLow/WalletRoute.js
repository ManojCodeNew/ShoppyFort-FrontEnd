import express from 'express';
import walletController from '../controller/WalletController.js';
import { authenticateAdmin } from "../middlewares/adminMiddleware.js";
import verifyToken from '../middlewares/authMiddleware.js';
const router = express.Router();
router.get('/getWallet', verifyToken, walletController.getWallet);
router.post("/credit", authenticateAdmin, walletController.creditWallet);
router.post("/process-wallet-payment", verifyToken, walletController.processWalletPayment);

export default router;