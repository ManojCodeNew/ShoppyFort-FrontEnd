import { createContext, useCallback, useEffect, useState, useContext } from "react";
import { useAuth } from "./AuthContext.jsx";
import { useNotification } from "@/components/Notify/NotificationProvider";
import sendGetRequestToBackend from "@/components/Request/Get.jsx";
import sendPostRequestToBackend from "@/components/Request/Post.jsx";

const WalletContext = createContext();
// Initial wallet state
const initialWalletState = {
    balance: 0,
    transactions: [],
    currency: 'AED',
    lastUpdated: null
};
export default function WalletProvider({ children }) {
    const { token, user } = useAuth();
    const { showNotification } = useNotification();

    const [wallet, setWallet] = useState(null);
    const [loading, setLoading] = useState(true);
    const [processingPayment, setProcessingPayment] = useState(false);
    const [initialized, setInitialized] = useState(false);

    // Fetch wallet details
    const getWallet = useCallback(async () => {
        if (!token) {
            console.log("Skipping wallet fetch - missing token/user", token, user?._id);
            console.log("Skipping wallet fetch - missing token/user or already loading");
            return;
        }
        setLoading(true);
        try {
            const response = await sendGetRequestToBackend("auth/wallet/getWallet", token);
            console.log("Wallet fetch response:", response);
            if (response?.success) {
                console.log("Wallet fetched successfully:", response);
                setWallet({
                    balance: response.wallet.balance || 0,
                    transactions: response.wallet.transactions || [],
                    currency: 'AED',
                    lastUpdated: new Date().toISOString()
                });
            } else {
                if (response?.error && !response.error.includes('not found')) {
                    showNotification(response.error, "error");
                }
                // Don't reset to initial state if wallet doesn't exist - that's normal
                if (response?.wallet == null) {
                    setWallet(initialWalletState);
                }
            }
        } catch (error) {
            console.error("Wallet fetch error:", error);
            showNotification("Network error fetching wallet", "error");
            // setWallet(initialWalletState);
        } finally {
            setLoading(false);
            setInitialized(true);
        }
    }, [token, user?._id, showNotification]);

    const processWalletPayment = useCallback(async (orderTotalAmt, orderId, paymentMethod) => {

        if (!user?._id) {
            showNotification("User not authenticated", "error");
            return {
                success: false,
                error: "User not authenticated",
                code: "UNAUTHENTICATED"
            };
        }
        if (processingPayment) {
            return {
                success: false,
                error: "Payment already in progress",
                code: "PAYMENT_IN_PROGRESS"
            };
        }

        setProcessingPayment(true);
        try {
            console.log(" userid:", user._id,
                orderTotalAmt,
                "orderid:", orderId,
                paymentMethod);

            const response = await sendPostRequestToBackend("auth/wallet/process-wallet-payment", {
                userid: user._id,
                orderTotalAmt,
                orderid: orderId,
                paymentMethod,
            }, token);
            console.log("Payment response:", response);
            if (!response) {
                throw new Error("No response from server");
            }
            // userid, orderTotalAmt, orderid, paymentMethod 
            if (response.success) {
                setWallet(prev => ({
                    ...prev,
                    balance: response.newBalance || prev.balance,
                    transactions: [
                        {
                            _id: new Date().getTime().toString(),
                            amount: response.amountPaidFromWallet || 0,
                            orderid: orderId,
                            date: new Date().toISOString(),
                            type: 'debit',
                            note: `Payment for order ${orderId}`,
                            status: 'completed'
                        },
                        ...(prev.transactions || [])
                    ],
                    lastUpdated: new Date().toISOString()
                }));
                return {
                    success: true,
                    amountPaid: response.amountPaidFromWallet || 0,
                    remaining: response.remainingAmount || 0,
                    paymentMethod: response.paymentMethod,
                    newBalance: response.newBalance
                };
            } else {
                showNotification(response.error || "Payment processing failed", "error");
                return {
                    success: false,
                    error: response.error || "Payment failed",
                    code: response.code || "PAYMENT_FAILED"
                };
            }
        } catch (error) {
            console.error("Payment error:", error);
            showNotification("Payment processing failed", "error");
            return {
                success: false,
                error: error.message || "Network error",
                code: "NETWORK_ERROR"
            };
        } finally {
            setProcessingPayment(false);
        }
    }, [user?._id, token, showNotification, processingPayment]);

    // Initialize wallet once when user and token are available
    useEffect(() => {
        if (user?._id && token && !initialized) {
            console.log("Initializing wallet for user:", user._id);
            getWallet();
        }
    }, [user?._id, token, initialized, getWallet]);


    const value = {
        wallet,
        loading,
        getWallet,
        processWalletPayment,
        paymentProcessing: processingPayment,
        initialized
    };

    return (
        <WalletContext.Provider value={value}>
            {children}
        </WalletContext.Provider>
    );
}

export const useWallet = () => {
    return useContext(WalletContext);
};