import mongoose from "mongoose";
const walletSchema = mongoose.Schema({
    userid: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    balance: { type: Number, required: true, default: 0, min: 0 },
    transactions: [
        {
            amount: Number,
            type: { type: String, enum: ["credit", "debit"], required: true }, // e.g., "credit" or "debit"
            note: String,
            date: { type: Date, default: Date.now },
            returnid: { type: mongoose.Schema.Types.ObjectId, ref: 'Return' },
            orderid: { type: String },
            productid: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
            status: {
                type: String,
                enum: ["pending", "completed", "failed", "reversed"],
                default: "completed"
            },
        }
    ]
},
    { timestamps: true });
const walletModel = mongoose.model('Wallet', walletSchema);
export default walletModel;