import express from 'express';
import orderController from '../controller/OrderController.js';
import verifyToken from '../middlewares/authMiddleware.js';
const router = express.Router();

router.post("/addOrder", verifyToken, orderController.addOrder);
router.get("/", verifyToken, orderController.getALLOrders);
router.post("/Return", verifyToken, orderController.submitReturnRequest);
router.post("/cancel", verifyToken, orderController.cancelOrder);
router.get("/returns", verifyToken, orderController.getReturns);



export default router;