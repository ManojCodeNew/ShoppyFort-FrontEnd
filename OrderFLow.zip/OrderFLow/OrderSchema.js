import mongoose from "mongoose";
const orderSchema = new mongoose.Schema({
    orderid: {
        type: String,
        required: true,
        unique: true
    },
    userid: {
        type: String,
        required: true,
    },
    shippingaddress: {
        type: Object,
        required: true
    },
    items: {
        type: Object,
        default: {}
    },
    totalprice: {
        type: Number,
        required: true
    },
    paymentMethod: {
        type: String,
        enum: ['COD', 'Online', 'wallet_partial', 'wallet'],
        required: true
    },
    amountPaidFromWallet: {
        type: Number,
        default: 0
    },
    paymentDetails: {
        paymentIntentId: String,
        amount: Number,
        currency: {
            type: String,
            default: 'aed'
        },
        method: String,
        cardLast4: String,
        status: String
    },
    isPaid: {
        type: Boolean,
        default: false
    },
    status: {
        type: String,
        enum: ['placed', 'shipped', 'delivered'],
        default: 'placed'
    },
    deliveredAt: { type: Date, default: null },

}, {
    timestamps: true
});
const orderModel = new mongoose.model("Order", orderSchema);
export default orderModel;