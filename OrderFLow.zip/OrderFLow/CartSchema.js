import mongoose from "mongoose";
const cartSchema = new mongoose.Schema({
    userid: {
        type: String,
        required: true
    },
    productid: {
        type: String,
        required: true,
    },
    quantity: {
        type: Number,
        default: 1
    },
    selections: {
        type: Object,
        default: {}
    }

}, {
    timestamps: true
});
const cartModel = new mongoose.model("cart", cartSchema);
export default cartModel;